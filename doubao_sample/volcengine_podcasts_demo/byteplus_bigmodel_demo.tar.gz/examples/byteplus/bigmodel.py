#!/usr/bin/env python3
import argparse
import asyncio
import json
import logging
import uuid

import websockets

from protocols import (
    MsgType,
    MsgTypeFlagBits,
    audio_only_client,
    full_client_request,
    receive_message,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--appid", required=True, help="APP ID")
    parser.add_argument("--access_token", required=True, help="Access Token")
    parser.add_argument(
        "--resource-id",
        default="volc.bigasr.sauc.duration",
        help="Resource ID",
    )
    parser.add_argument(
        "--endpoint",
        default="wss://voice.ap-southeast-1.bytepluses.com/api/v3/sauc/bigmodel",
        help="WebSocket endpoint URL",
    )
    parser.add_argument("--file", required=True, help="Audio file path")

    args = parser.parse_args()

    # Connect to server
    headers = {
        "X-Api-App-Key": args.appid,
        "X-Api-Access-Key": args.access_token,
        "X-Api-Resource-Id": args.resource_id,
        "X-Api-Connect-Id": str(uuid.uuid4()),
    }

    logger.info(f"Connecting to {args.endpoint} with headers: {headers}")
    websocket = await websockets.connect(args.endpoint, additional_headers=headers)
    logger.info(
        f"Connected to WebSocket server, Logid: {websocket.response.headers['x-tt-logid']}",
    )

    try:
        # Prepare request payload
        sample_rate = 24000
        request = {
            "user": {
                "uid": str(uuid.uuid4()),
            },
            "audio": {
                "format": "wav",
                "rate": sample_rate,
                "bits": 16,
                "channel": 1,
            },
            "request": {
                "model_name": "bigmodel",
                "enable_itn": True,
                "enable_punc": True,
                "enable_ddc": True,
                "show_utterances": True,
            },
        }

        # Send task information
        await full_client_request(websocket, json.dumps(request).encode())

        # Read audio file
        with open(args.file, "rb") as f:
            audio_data = f.read()

        # Send audio data in chunks
        chunk_size = 2 * sample_rate // 10  # 100ms of audio data

        async def send_audio():
            for i in range(0, len(audio_data), chunk_size):
                end = i + chunk_size
                last_payload = False
                if end > len(audio_data):
                    end = len(audio_data)
                    last_payload = True

                flag = MsgTypeFlagBits.NoSeq
                if last_payload:
                    flag = MsgTypeFlagBits.LastNoSeq

                await audio_only_client(websocket, audio_data[i:end], flag)

                if last_payload:
                    break

                await asyncio.sleep(0.1)  # 100ms delay between chunks

        # Start sending audio in background
        send_task = asyncio.create_task(send_audio())

        # Wait for results
        while True:
            msg = await receive_message(websocket)

            if msg.type == MsgType.FullServerResponse:
                if msg.flag == MsgTypeFlagBits.NegativeSeq:
                    break
            else:
                raise RuntimeError(f"ASR failed: {msg}")

        # Wait for send_audio to complete
        await send_task

    finally:
        await websocket.close()
        logger.info("Connection closed")


if __name__ == "__main__":
    asyncio.run(main())
